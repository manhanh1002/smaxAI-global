# 07_UX_UI_FLOWS.md - UX/UI Flows & Screen Design

## 1. Information Architecture

### 1.1 Site Map

```
Dashboard (Home)
├── Conversation Center
│   ├── Inbox (with filters)
│   ├── Lead Profile
│   ├── Conversation History
│   ├── AI Assistant Panel
│   └── Booking Status
├── Booking Management
│   ├── All Bookings (view)
│   ├── Booking Detail (edit/manage)
│   ├── Slots Management
│   ├── Schedule View (calendar)
│   └── Analytics (funnel metrics)
├── SOP Management
│   ├── SOP Builder (no-code)
│   ├── SOP Templates (by vertical)
│   ├── Rule Configuration
│   └── Checklist Management
├── Team Management
│   ├── Users
│   ├── Roles & Permissions
│   ├── Activity Log
│   └── Integrations
└── Settings
    ├── Organization
    ├── Billing
    ├── API Keys
    └── Integrations (WhatsApp, Messenger)
```

---

## 2. Core User Flows

### 2.1 Flow 1: Sales Receives Lead → Creates Booking

```
┌─────────────────────────────────────────┐
│ Lead arrives (WhatsApp message)         │
│ "Tôi muốn bọc sứ, bao nhiêu tiền?"     │
└────────────────┬────────────────────────┘
                 │
                 ▼
        ┌────────────────────┐
        │ System detects:    │
        │ - New lead         │
        │ - Service inquiry  │
        │ - Missing: date    │
        └────────┬───────────┘
                 │
                 ▼
        ┌──────────────────────────────────┐
        │ UI Shows:                        │
        │ [Conversation Summary]           │
        │ "Customer asks about pricing"    │
        │                                  │
        │ [Missing Info Alert]             │
        │ ⚠ Need: appointment_date         │
        │                                  │
        │ [AI Suggestions]                 │
        │ Option A: Professional reply     │
        │ Option B: Casual reply           │
        │ [Edit] [Suggest]                 │
        └────────┬─────────────────────────┘
                 │
        Sales chooses reply
                 │
                 ▼
        ┌──────────────────────────────┐
        │ Message sent to customer     │
        │ State: INQUIRY → awaiting    │
        │ follow-up                    │
        └──────────────────────────────┘
                 │
        Customer responds: "Thứ 3 lúc 9h được không?"
                 │
                 ▼
        ┌────────────────────────────────┐
        │ System validates:             │
        │ ✓ Service confirmed          │
        │ ✓ Appointment date provided  │
        │ Can move to: SLOT_PROPOSED   │
        └────────┬─────────────────────┘
                 │
        Sales approves state change
                 │
                 ▼
        ┌──────────────────────────────┐
        │ Booking created with:        │
        │ - Service: Bọc sứ            │
        │ - Date: Thứ 3 (T3)           │
        │ - Time: 09:00                │
        │ - State: SLOT_PROPOSED       │
        │ - Status: Awaiting confirm   │
        └──────────────────────────────┘
```

### 2.2 Flow 2: Customer Confirms Booking

```
Lead confirms: "Vâng, xác nhận Thứ 3 lúc 9h"
        │
        ▼
System detects confirmation intent
        │
        ▼
┌──────────────────────────────┐
│ Validation Checklist         │
│ ✓ Service: Bọc sứ            │
│ ✓ Date: T3                   │
│ ✓ Time: 09:00                │
│ ✓ Customer confirmed (Y/N)   │
│ ✓ Slot still available       │
└────────┬─────────────────────┘
         │ All checks pass
         ▼
┌──────────────────────────────┐
│ BOOKING STATE CHANGE         │
│ SLOT_PROPOSED → CONFIRMED    │
│                              │
│ [Confirm] [Edit] [Cancel]    │
└────────┬─────────────────────┘
         │ Sales confirms
         ▼
┌──────────────────────────────┐
│ Booking Confirmed!           │
│                              │
│ Service: Bọc sứ              │
│ Date: T3, 10/02              │
│ Time: 09:00                  │
│ Provider: Dr. Nguyễn Văn A   │
│                              │
│ [Send reminder] [Reschedule] │
│ [Payment link] [Done]        │
└──────────────────────────────┘
         │
         ▼
Auto-send to customer:
"Cảm ơn! Appointment của bạn:
Thứ 3 - 10/02 - 09:00 - Bọc sứ
Địa chỉ: [clinic address]
[Map link]"
```

### 2.3 Flow 3: Appointment Reminder & Show-up

```
T-24h before appointment (09:00 on 2024-02-09)
        │
        ▼
System triggers: REMINDER_SENT state
        │
        ▼
┌──────────────────────────────────┐
│ Auto-send reminder message:      │
│ "Nhắc nhở: Ngày mai (T3 10/02)   │
│ bạn có appointment nha. Chuẩn bị │
│ sớm 10 phút."                    │
│                                  │
│ [Map link] [Confirm] [Reschedule]│
└────────┬─────────────────────────┘
         │
    Customer can respond:
    - "Có" (confirm) → No further action
    - "Không được" (can't) → Trigger reschedule flow
    - No response → Resend at T-2h
         │
         ▼
    Appointment time arrives (09:00)
         │
         ▼
┌────────────────────────────────┐
│ Clinic staff inputs show-up:   │
│ [Customer came ✓]              │
│ [Customer didn't come ✗]       │
│ [Rescheduled]                  │
└────────┬───────────────────────┘
         │
      Staff marks: "Customer came"
         │
         ▼
┌────────────────────────────────┐
│ Booking state: COMPLETED       │
│ Show-up: YES                   │
│                                │
│ [Schedule follow-up]           │
│ [Collect review]               │
│ [Done]                         │
└────────────────────────────────┘
```

---

## 3. Screen Wireframes

### 3.1 Main Dashboard

```
┌─────────────────────────────────────────────────────┐
│  [Logo]              Booking System          [User] │
├─────────────────────────────────────────────────────┤
│                                                     │
│ Sidebar              Main Content                  │
│ ┌──────────┐        ┌───────────────────────────┐ │
│ │ Chats    │        │ INBOX - 12 leads          │ │
│ │ Booking  │        │                           │ │
│ │ SOP      │        │ Filter: [All] [Hot] [Cold] │
│ │ Team     │        │                           │ │
│ │ Settings │        │ ┌─────────────────────┐   │ │
│ │          │        │ │ 🔴 URGENT           │   │ │
│ │          │        │ │ Nguyễn Văn A        │   │ │
│ │          │        │ │ "Tôi muốn bọc sứ"   │   │ │
│ │          │        │ │ 2 phút trước         │   │ │
│ │          │        │ └─────────────────────┘   │ │
│ │          │        │ ┌─────────────────────┐   │ │
│ │          │        │ │ ✓ BOOKED            │   │ │
│ │          │        │ │ Trần Thị B          │   │ │
│ │          │        │ │ T3 - 10/02 - 09:00  │   │ │
│ │          │        │ │ 1 giờ trước          │   │ │
│ │          │        │ └─────────────────────┘   │ │
│ │          │        │                           │ │
│ │          │        │ [Load more...]            │ │
│ │          │        │                           │ │
│ └──────────┘        └───────────────────────────┘ │
│                                                     │
└─────────────────────────────────────────────────────┘
```

### 3.2 Conversation Center

```
┌─────────────────────────────────────────────────────┐
│ Lead: Nguyễn Văn A | Phone: 0901234567            │
│ Source: WhatsApp | State: INQUIRY                  │
├─────────────────────────────────────────────────────┤
│                                                     │
│ Conversation Timeline      │  AI Assistant Panel   │
│ ┌─────────────────────┐   │ ┌──────────────────┐  │
│ │ Sales (10:00)       │   │ │ SUMMARY          │  │
│ │ "Xin chào, clinic   │   │ │ Customer wants   │  │
│ │ nha khoa..."        │   │ │ porcelain crown  │  │
│ │                     │   │ │ crown for front  │  │
│ │ Lead (10:05)        │   │ │ tooth            │  │
│ │ "Tôi muốn bọc sứ    │   │ │                  │  │
│ │ cho răng cửa, bao   │   │ │ MISSING INFO     │  │
│ │ nhiêu tiền?"        │   │ │ ⚠ appointment_   │  │
│ │                     │   │ │  date (needed    │  │
│ │ Sales (10:10) [WAIT]│   │ │  to propose)     │  │
│ │ [Suggestion pending]│   │ │ ⚠ confirm first  │  │
│ │                     │   │ │  time visit      │  │
│ │                     │   │ │                  │  │
│ │                     │   │ │ REPLY OPTIONS    │  │
│ │ Message input:      │   │ │ A) Professional  │  │
│ │ ┌─────────────────┐ │   │ │ B) Friendly      │  │
│ │ │ Type message... │ │   │ │ [Choose] [Edit]  │  │
│ │ └─────────────────┘ │   │ │ [Custom]         │  │
│ │ [Send] [Suggest]    │   │ │                  │  │
│ │                     │   │ └──────────────────┘  │
│ └─────────────────────┘   │                       │
│                           │ BOOKING STATUS       │
│                           │ ┌──────────────────┐ │
│                           │ │ State: INQUIRY    │ │
│                           │ │ [Move to Service] │ │
│                           │ │                  │ │
│                           │ │ Next action:     │ │
│                           │ │ Ask for date     │ │
│                           │ └──────────────────┘ │
└─────────────────────────────────────────────────────┘
```

### 3.3 Booking Management

```
┌─────────────────────────────────────────────────────┐
│ BOOKINGS (15 total)                                 │
│ Filter: [All] [This week] [Next week] [Overdue]    │
├─────────────────────────────────────────────────────┤
│                                                     │
│ ┌─────────────────────────────────────────────────┐ │
│ │ 1. Nguyễn Văn A                                 │ │
│ │    Status: ✓ CONFIRMED                          │ │
│ │    Service: Bọc sứ (30 phút)                    │ │
│ │    Date: T3, 10/02, 09:00                       │ │
│ │    Provider: Dr. Nguyễn Văn A                   │ │
│ │    Payment: Pending ($500)                      │ │
│ │    Actions: [Pay] [Remind] [Reschedule] [More] │ │
│ └─────────────────────────────────────────────────┘ │
│                                                     │
│ ┌─────────────────────────────────────────────────┐ │
│ │ 2. Trần Thị B                                   │ │
│ │    Status: 🟠 REMINDER_SENT (in 2 hours)       │ │
│ │    Service: Tẩy trắng (45 phút)                │ │
│ │    Date: Today, 14:00                           │ │
│ │    Provider: Dr. Trần Văn C                     │ │
│ │    Show-up: Not yet marked                      │ │
│ │    Actions: [Mark show-up] [Remind] [Reschedule]│ │
│ └─────────────────────────────────────────────────┘ │
│                                                     │
│ [Show calendar view] [Export] [Settings]           │
│                                                     │
└─────────────────────────────────────────────────────┘
```

### 3.4 SOP Builder (No-code)

```
┌─────────────────────────────────────────────────────┐
│ SOP BUILDER - Clinic Dental                          │
│                                                     │
│ [Save] [Publish] [Test] [Template Gallery]         │
├─────────────────────────────────────────────────────┤
│                                                     │
│ STATE 1: INQUIRY                                    │
│ ┌─────────────────────────────────────────────────┐ │
│ │ ✓ Required fields:                              │ │
│ │ ☑ service_type  ☑ phone  ☑ name                 │ │
│ │                                                  │ │
│ │ Allowed actions:                                │ │
│ │ ☑ Ask for service  ☑ Propose service           │ │
│ │ ☑ Schedule call    ☑ Send info                 │ │
│ │                                                  │ │
│ │ Next states:                                    │ │
│ │ → SERVICE_SELECTED [conditions: service !=null] │ │
│ │                                                  │ │
│ │ Messages (templates):                           │ │
│ │ [+ Add] "Xin chào! Clinic chúng tôi..."        │ │
│ └─────────────────────────────────────────────────┘ │
│                                                     │
│ STATE 2: SERVICE_SELECTED                           │
│ ┌─────────────────────────────────────────────────┐ │
│ │ ✓ Required fields:                              │ │
│ │ ☑ appointment_date  ☑ slot_time                 │ │
│ │                                                  │ │
│ │ Blocking rules:                                 │ │
│ │ [+ Add rule] Min 24h notice for appointment     │ │
│ │                                                  │ │
│ │ Next states:                                    │ │
│ │ → SLOT_PROPOSED                                │ │
│ │ → CANCELLED                                     │ │
│ └─────────────────────────────────────────────────┘ │
│                                                     │
│ [+ Add state]                                      │ │
│                                                     │
└─────────────────────────────────────────────────────┘
```

---

## 4. Mobile Experience

### 4.1 Mobile Inbox

```
iPhone Screen:

┌──────────────────────────┐
│ ◀ Inbox (5)              │
├──────────────────────────┤
│                          │
│ 🔴 Nguyễn Văn A          │
│ "Tôi muốn bọc sứ"        │
│ 2 phút                   │
│                          │
│ 💬 Trần Thị B            │
│ "Mình đã thanh toán"     │
│ 10 phút                  │
│                          │
│ ✓ Lê Văn C               │
│ T3 09:00 - Confirmed     │
│ 2 giờ                    │
│                          │
│ ⏳ Phạm Thị D             │
│ Reminder sent            │
│ 1 giờ                    │
│                          │
└──────────────────────────┘
│ [+] [🔔] [⚙]             │ (bottom nav)
└──────────────────────────┘
```

### 4.2 Mobile Conversation

```
┌──────────────────────────┐
│ ◀ Nguyễn Văn A          │
├──────────────────────────┤
│                          │
│ Sales (10:00)            │
│ ┌────────────────────┐   │
│ │ Xin chào, clinic   │   │
│ │ nha khoa chúng     │   │
│ │ tôi...             │   │
│ └────────────────────┘   │
│                          │
│ Lead (10:05)             │
│ ┌────────────────────┐   │
│ │ Tôi muốn bọc sứ    │   │
│ │ cho răng cửa       │   │
│ └────────────────────┘   │
│                          │
│ AI Suggestion:           │
│ ┌────────────────────┐   │
│ │ Option A [Professional]
│ │ Option B [Friendly] │   │
│ │ [+] Edit suggestion│   │
│ └────────────────────┘   │
│                          │
│ Message input:           │
│ ┌────────────────────┐   │
│ │ Type message... 🎤 │   │
│ └────────────────────┘   │
│                          │
└──────────────────────────┘
```

---

## 5. Design System

### 5.1 Color Palette

```
Primary Colors:
- Primary Blue: #0066CC (CTAs, active states)
- Success Green: #28A745 (Confirmations, completed)
- Warning Orange: #FFC107 (Pending, warnings)
- Error Red: #DC3545 (Errors, urgent)
- Neutral Gray: #6C757D (Secondary text, disabled)

Background:
- White: #FFFFFF (Main background)
- Light Gray: #F8F9FA (Secondary background)
- Dark Gray: #2C3E50 (Dark text)

Accent:
- Sky Blue: #E3F2FD (Background for info boxes)
- Light Green: #E8F5E9 (Background for success)
```

### 5.2 Typography

```
Font Family: Inter / -apple-system

Headings:
- H1: 32px, Bold, #2C3E50
- H2: 24px, Bold, #2C3E50
- H3: 18px, Semi-bold, #2C3E50

Body:
- Body: 14px, Regular, #6C757D
- Body Small: 12px, Regular, #6C757D
- Caption: 12px, Regular, #999999

Interactive:
- Button text: 14px, Semi-bold
- Link: 14px, Regular, underline, #0066CC
```

### 5.3 Component Library

```
Buttons:
- Primary (Blue)
- Secondary (Gray outline)
- Danger (Red)
- Success (Green)
- Loading state

Forms:
- Text input (with placeholder)
- Select dropdown
- Checkbox
- Radio button
- Date picker
- Time picker

Cards:
- Lead card
- Booking card
- Message bubble
- Alert/notification
- Empty state

Modals:
- Confirmation dialog
- Form modal
- Error modal
- Success toast
```

---

## 6. Accessibility Requirements

### 6.1 A11y Guidelines

- ✓ WCAG 2.1 Level AA compliance
- ✓ Keyboard navigation support
- ✓ Screen reader friendly (semantic HTML)
- ✓ Color contrast ratio ≥ 4.5:1
- ✓ Focus indicators visible
- ✓ Error messages clear and linked to form fields
- ✓ Language attribute on HTML
- ✓ Alt text for images
- ✓ Form labels associated with inputs

---

## 7. Performance Targets

### 7.1 Loading & Interaction

```
- Initial page load: < 2s
- Message send: < 500ms
- AI suggestion appearance: < 2s
- State transition: < 1s
- Search results: < 1s
- Mobile: 20% slower than desktop
- TTI (Time to Interactive): < 3.5s
- FCP (First Contentful Paint): < 1.5s
- LCP (Largest Contentful Paint): < 2.5s
```

---

**Tài liệu liên quan:**
- [04_FEATURE_DETAILS.md](04_FEATURE_DETAILS.md)
- [05_AI_LOGIC_ARCHITECTURE.md](05_AI_LOGIC_ARCHITECTURE.md)
- [06_BOOKING_ORCHESTRATION_ENGINE.md](06_BOOKING_ORCHESTRATION_ENGINE.md)

**Última actualización**: Feb 2026  
**Status**: In Review  
**Version**: 1.0-MVP
